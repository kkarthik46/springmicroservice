package com.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;


@Controller
public class StudentController {
	Logger log=Logger.getAnonymousLogger();
	
	@Autowired
	Studentrepo repo;
	RestTemplate temp=new RestTemplate();
	@ResponseBody
	@RequestMapping("login")
	public String checklogin(HttpServletRequest req,HttpServletResponse res) {
		String user=req.getParameter("suser");
		String password=req.getParameter("spassword");
			if(repo.findByName(user)!=null) {
				return "Login successful"+"\n "+"Welcome to "+user;
			}
			else {
				return "check the credentials or register";
			}
		
	}
	
	@RequestMapping("register")
	public String microserviceOfregister(HttpServletRequest req,HttpServletResponse res) {
		String user=req.getParameter("suser");
		String password=req.getParameter("spassword");
		String email=req.getParameter("semail");
		log.info("in micro service of register");
		String url="http://localhost:8099/register-user/"+user+"/"+password+"/"+email;
		System.out.println(url);
		temp.getForObject(url,String.class);
		return "success";
		
		
	}
	
	
	

}
