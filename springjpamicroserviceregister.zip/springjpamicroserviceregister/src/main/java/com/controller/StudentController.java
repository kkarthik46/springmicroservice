package com.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class StudentController {
	@Autowired
	Studentrepo repo;
	
	Logger log=Logger.getAnonymousLogger();
	@ResponseBody
	@RequestMapping("/register-user/{user}/{password}/{email}")
	public String register(@PathVariable("user") String user,@PathVariable("password") String password,@PathVariable("email") String email,HttpServletRequest req,HttpServletResponse res) {
		
		log.info("in register proj of microservice");
		Student s=new Student();
		s.setSuser(user);
		s.setSpassword(password);
		s.setEmail(email);
		repo.save(s);
		return "successfully registered";
	}
	
	
	

}
